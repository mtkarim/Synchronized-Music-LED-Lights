/* ###################################################################
**     Filename    : ProcessorExpert.c
**     Project     : ProcessorExpert
**     Processor   : MCF51EM256CLL
**     Version     : Driver 01.00
**     Compiler    : CodeWarrior ColdFireV1 C Compiler
**     Date/Time   : 2013-07-29, 16:12, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file ProcessorExpert.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup ProcessorExpert_module ProcessorExpert module documentation
**  @{
*/         
/* MODULE ProcessorExpert */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Bit1.h"
/* Include shared modules, which are used for whole project */
#include <stdio.h>
#include "LCD_HAL.h"
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */

int pre16 = 0;
int ledON = 0;
void delay(int n);

void delay(int n){	//Busy wait function
	int i = 0;
	for(i; i < n*1000; i++){} //Have processor go through a loop that does nothing 
}

void main(void)
{
  /* Write your local variable definition here */
	unsigned char temp[64]="Hat: 0";
	unsigned char *temp2;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  vfnLCD_Init();
  vfnLCD_Set_Display();
  vfnLCD_Clear_Display();
  for(;;){
	  temp2 = &temp[0];
	  vfnLCD_Write_Msg(temp2);
	  
	  if(!(Bit1_GetVal())){ //If the LED is on
		  pre16++;			//Counter was counting too early so we needed a small buffer
		  if(pre16 > 16){	//We knew the counter was 16 too early
			  ledON++;		//Increment counter
		  }
		  sprintf((char*)&temp, "Hat: %d", ledON);	//Print the count
		  delay(50);		//Counter counting too fast, needed delay
	  }	 
  }
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END ProcessorExpert */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.2 [05.07]
**     for the Freescale ColdFireV1 series of microcontrollers.
**
** ###################################################################
*/
